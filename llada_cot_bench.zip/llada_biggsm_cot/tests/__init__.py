"""Test suite for LLaDA CoT benchmark."""
